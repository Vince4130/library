import Livre from "./classes/Livre.js";
import Membre from "./classes/Membre.js";
import Bibliotheque from "./classes/Bibliotheque.js";

const livre = new Livre("1984", "George Orwell");
const livre2 = new Livre("Le Petit Prince", "Antoine de Saint-Exupéry");
const livre3 = new Livre("Le Seigneur des Anneaux", "J.R.R. Tolkien");
const livre4 = new Livre("Le Hobbit", "J.R.R. Tolkien");

const membre1 = new Membre("Dupont", "Jean", "t@t.fr");
const membre2 = new Membre("Martin", "Marie", "t@t1.fr");

const bibliotheque = new Bibliotheque();

bibliotheque.ajouterLivre(livre);
bibliotheque.ajouterLivre(livre2);
bibliotheque.ajouterLivre(livre3);
bibliotheque.ajouterLivre(livre4);

bibliotheque.enregistrerMembre(membre1);
bibliotheque.enregistrerMembre(membre2);

bibliotheque.afficherLivresDisponibles();

membre1.emprunterLivre(livre);
membre1.emprunterLivre(livre2);

membre2.emprunterLivre(livre3);
membre2.emprunterLivre(livre4);

bibliotheque.afficherLivresDisponibles();

membre1.rendreLivre(livre);

bibliotheque.afficherLivresDisponibles();