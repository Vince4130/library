export default class Livre {
  #titre;
  #auteur;
  #statut; // disponible true, indisponible false

  constructor(titre, auteur, statut = true) {
    this.#titre = titre;
    this.#auteur = auteur;
    this.#statut = statut;
  }

  get titre() {
    return this.#titre;
  }
  set titre(titre) {
    this.#titre = titre;
  }

  get auteur() {
    return this.#auteur;
  }
  set auteur(auteur) {
    this.#auteur = auteur;
  }

  get statut() {
    return this.#statut;
  }

  emprunter() {
    if (this.#statut) {
      this.#statut = false;
      return true;
    } else {
      console.log(`Le livre "${this.#titre}" est déjà indisponible.`);
      return false;
    }
  }

  rendre() {
    if (!this.#statut) {
      this.#statut = true;
    } else {
      console.log(`Le livre "${this.#titre}" est déjà disponible.`);
    }

    return this.#statut;
  }

  toJSON() {
    return {
      custom: "LivreAAAAA",
      titre: this.#titre,
      auteur: this.#auteur,
      statut: this.#statut,
    };
  }
}
