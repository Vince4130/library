export default class Bibliotheque {
    #listeLivres;
    #listeMembres;

    constructor() {
        this.#listeLivres = [];
        this.#listeMembres = [];
    }

    get listeLivres() {
        return this.#listeLivres;
    }

    get listeMembres() {
        return this.#listeMembres;
    }

    ajouterLivre(livre) {
        this.#listeLivres.push(livre);
    }

    enregistrerMembre(membre) {
        this.#listeMembres.push(membre);
    }

    chercherLivre(titre) {
        // !titre <==> titre !== undefined && titre !== null
        if (!titre || typeof titre !== "string") {
            throw new Error("Le titre doit être une chaîne de caractères non vide.");
        }
        for (const livre of this.#listeLivres) {
            if (livre.titre.toLowerCase() === titre.toLowerCase()) {
                return livre;
            }
        }
        return null;
    }

    chercherMembre(id) {
        if (!id || typeof id !== "number") {
            throw new Error("L'ID doit être un nombre valide.");
        }
        for (const membre of this.#listeMembres) {
            if (membre.id === id) {
                return membre;
            }
        }
        return null;
    }

    afficherLivresDisponibles() {
        const livresDisponibles = [];
        for (const livre of this.#listeLivres) {
            if (livre.statut) {
                livresDisponibles.push(livre);
            }
        }
        console.log("Livres disponibles :");
        console.log(JSON.stringify(livresDisponibles, null, 2));
    }
}