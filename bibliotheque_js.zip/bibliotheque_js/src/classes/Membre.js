export default class Membre {
    #listeEmprunts;

    constructor(id, nom, prenom, email) {
        this.id = id; // Assuming id is a unique identifier for the member
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.#listeEmprunts = [];
    }

    get listeEmprunts() {
        return this.#listeEmprunts;
    }
    
    emprunterLivre(livre) {
        if (livre.emprunter()) {
            this.#listeEmprunts.push(livre);
            console.log(`${this.prenom} ${this.nom} a emprunté "${livre.titre}".`);
            return true;
        } else {
            console.log(`Impossible d'emprunter "${livre.titre}", il est indisponible.`);
            return false;
        }
    }

    rendreLivre(livre) {
        const index = this.#listeEmprunts.indexOf(livre);
        if (index !== -1) {
            livre.rendre();
            this.#listeEmprunts.splice(index, 1);
            console.log(`${this.prenom} ${this.nom} a rendu "${livre.titre}".`);
            return true;
        } else {
            console.log(`Le livre "${livre.titre}" n'est pas dans la liste des emprunts de ${this.prenom} ${this.nom}.`);
            return false;
        }
    }

    toJSON() {
        return {
            nom: this.nom,
            prenom: this.prenom,
            email: this.email,
            listeEmprunts: this.#listeEmprunts.map(livre => livre.toJSON())
        };
    }
}